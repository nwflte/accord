﻿// Accord Math Library
// The Accord.NET Framework
// http://accord-net.origo.ethz.ch
//
// Copyright © César Souza, 2009-2012
// cesarsouza at gmail.com
//
//    This library is free software; you can redistribute it and/or
//    modify it under the terms of the GNU Lesser General Public
//    License as published by the Free Software Foundation; either
//    version 2.1 of the License, or (at your option) any later version.
//
//    This library is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
//    Lesser General Public License for more details.
//
//    You should have received a copy of the GNU Lesser General Public
//    License along with this library; if not, write to the Free Software
//    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
//
namespace Accord.Math
{
    using System;
    using System.Collections.Generic;
    using AForge.Math.Random;
    using AForge;


    public static partial class Matrix
    {


        #region Diagonal matrices
        /// <summary>
        ///   Returns a square diagonal matrix of the given size.
        /// </summary>
        public static T[,] Diagonal<T>(int size, T value)
        {
            if (size < 0) throw new ArgumentOutOfRangeException("size", size,
                "Square matrix's size must be a positive integer.");

            T[,] matrix = new T[size, size];

            for (int i = 0; i < size; i++)
                matrix[i, i] = value;

            return matrix;
        }

        /// <summary>
        ///   Returns a matrix of the given size with value on its diagonal.
        /// </summary>
        public static T[,] Diagonal<T>(int rows, int cols, T value)
        {
            if (rows < 0) throw new ArgumentOutOfRangeException("rows", rows, "Number of rows must be a positive integer.");
            if (cols < 0) throw new ArgumentOutOfRangeException("cols", cols, "Number of columns must be a positive integer.");

            T[,] matrix = new T[rows, cols];

            int min = Math.Min(rows, cols);

            for (int i = 0; i < min; i++)
                matrix[i, i] = value;

            return matrix;
        }

        /// <summary>
        ///   Return a square matrix with a vector of values on its diagonal.
        /// </summary>
        public static T[,] Diagonal<T>(T[] values)
        {
            if (values == null) throw new ArgumentNullException("values");

            T[,] matrix = new T[values.Length, values.Length];

            for (int i = 0; i < values.Length; i++)
                matrix[i, i] = values[i];

            return matrix;
        }

        /// <summary>
        ///   Return a square matrix with a vector of values on its diagonal.
        /// </summary>
        public static T[,] Diagonal<T>(int size, T[] values)
        {
            return Diagonal(size, size, values);
        }

        /// <summary>
        ///   Returns a matrix with a vector of values on its diagonal.
        /// </summary>
        public static T[,] Diagonal<T>(int rows, int cols, T[] values)
        {
            if (values == null) throw new ArgumentNullException("values");
            if (rows < 0) throw new ArgumentOutOfRangeException("rows", rows, "Number of rows must be a positive integer.");
            if (cols < 0) throw new ArgumentOutOfRangeException("cols", cols, "Number of columns must be a positive integer.");

            T[,] matrix = new T[rows, cols];

            for (int i = 0; i < values.Length; i++)
                matrix[i, i] = values[i];

            return matrix;
        }
        #endregion

        #region Special matrices
        /// <summary>
        ///   Returns the Identity matrix of the given size.
        /// </summary>
        public static double[,] Identity(int size)
        {
            return Diagonal(size, 1.0);
        }

        /// <summary>
        ///   Creates a magic square matrix.
        /// </summary>
        public static double[,] Magic(int size)
        {
            if (size < 3) throw new ArgumentOutOfRangeException("size", size,
                "The square size must be greater or equal to 3.");

            double[,] matrix = new double[size, size];


            // First algorithm: Odd order
            if ((size % 2) == 1)
            {
                int a = (size + 1) / 2;
                int b = (size + 1);

                for (int j = 0; j < size; j++)
                    for (int i = 0; i < size; i++)
                        matrix[i, j] = size * ((i + j + a) % size) + ((i + 2 * j + b) % size) + 1;
            }

            // Second algorithm: Even order (double)
            else if ((size % 4) == 0)
            {
                for (int j = 0; j < size; j++)
                    for (int i = 0; i < size; i++)
                        if (((i + 1) / 2) % 2 == ((j + 1) / 2) % 2)
                            matrix[i, j] = size * size - size * i - j;
                        else
                            matrix[i, j] = size * i + j + 1;
            }

            // Third algorithm: Even order (single)
            else
            {
                int n = size / 2;
                int p = (size - 2) / 4;
                double t;

                double[,] block = Matrix.Magic(n);

                for (int j = 0; j < n; j++)
                {
                    for (int i = 0; i < n; i++)
                    {
                        double e = block[i, j];
                        matrix[i, j] = e;
                        matrix[i, j + n] = e + 2 * n * n;
                        matrix[i + n, j] = e + 3 * n * n;
                        matrix[i + n, j + n] = e + n * n;
                    }
                }

                for (int i = 0; i < n; i++)
                {
                    // Swap M[i,j] and M[i+n,j]
                    for (int j = 0; j < p; j++)
                    {
                        t = matrix[i, j];
                        matrix[i, j] = matrix[i + n, j];
                        matrix[i + n, j] = t;
                    }
                    for (int j = size - p + 1; j < size; j++)
                    {
                        t = matrix[i, j];
                        matrix[i, j] = matrix[i + n, j];
                        matrix[i + n, j] = t;
                    }
                }

                // Continue swaping in the boundary
                t = matrix[p, 0];
                matrix[p, 0] = matrix[p + n, 0];
                matrix[p + n, 0] = t;

                t = matrix[p, p];
                matrix[p, p] = matrix[p + n, p];
                matrix[p + n, p] = t;
            }

            return matrix; // return the magic square.
        }

        #endregion



        #region Vector creation
        /// <summary>
        ///   Creates a matrix with a single row vector.
        /// </summary>
        public static T[,] RowVector<T>(params T[] values)
        {
            if (values == null) throw new ArgumentNullException("values");

            T[,] matrix = new T[1, values.Length];

            for (int i = 0; i < values.Length; i++)
                matrix[0, i] = values[i];

            return matrix;
        }

        /// <summary>
        ///   Creates a matrix with a single column vector.
        /// </summary>
        public static T[,] ColumnVector<T>(params T[] values)
        {
            if (values == null) throw new ArgumentNullException("values");

            T[,] matrix = new T[values.Length, 1];

            for (int i = 0; i < values.Length; i++)
                matrix[i, 0] = values[i];

            return matrix;
        }

        /// <summary>
        ///   Creates a vector with the given dimension and starting values.
        /// </summary>
        public static T[] Vector<T>(int n, T[] values)
        {
            T[] vector = new T[n];

            if (values != null)
            {
                for (int i = 0; i < values.Length; i++)
                    vector[i] = values[i];
            }

            return vector;
        }

        /// <summary>
        ///   Creates a vector with the given dimension and starting values.
        /// </summary>
        public static T[] Vector<T>(int n, T value)
        {
            T[] vector = new T[n];

            for (int i = 0; i < n; i++)
                vector[i] = value;

            return vector;
        }
        #endregion

        #region Special vectors
        /// <summary>
        ///   Creates a index vector.
        /// </summary>
        public static int[] Indices(int from, int to)
        {
            int[] vector = new int[to - from];
            for (int i = 0; i < vector.Length; i++)
                vector[i] = from++;
            return vector;
        }

        /// <summary>
        ///   Creates an interval vector.
        /// </summary>
        public static int[] Interval(int from, int to)
        {
            int[] vector = new int[to - from + 1];
            for (int i = 0; i < vector.Length; i++)
                vector[i] = from++;
            return vector;
        }

        /// <summary>
        ///   Creates an interval vector.
        /// </summary>
        public static double[] Interval(DoubleRange range, double stepSize)
        {
            return Interval(range.Min, range.Max, stepSize);
        }

        /// <summary>
        ///   Creates an interval vector.
        /// </summary>
        public static double[] Interval(double from, double to, double stepSize)
        {
            double range = to - from;
            int steps = (int)Math.Ceiling(range / stepSize) + 1;

            double[] r = new double[steps];
            for (int i = 0; i < r.Length; i++)
                r[i] = from + i * stepSize;

            return r;
        }

        /// <summary>
        ///   Creates an interval vector.
        /// </summary>
        public static float[] Interval(float from, float to, double stepSize)
        {
            float[] r;

            if (from > to)
            {
                double range = from - to;
                int steps = (int)Math.Ceiling(range / stepSize) + 1;

                r = new float[steps];
                for (int i = 0; i < r.Length; i++)
                    r[i] = (float)(from - i * stepSize);
                r[steps - 1] = to;
            }
            else
            {
                double range = to - from;
                int steps = (int)Math.Ceiling(range / stepSize) + 1;

                r = new float[steps];
                for (int i = 0; i < r.Length; i++)
                    r[i] = (float)(from + i * stepSize);
                r[steps - 1] = to;
            }

            return r;
        }

        /// <summary>
        ///   Creates an interval vector.
        /// </summary>
        public static double[] Interval(DoubleRange range, int steps)
        {
            return Interval(range.Min, range.Max, steps);
        }

        /// <summary>
        ///   Creates an interval vector.
        /// </summary>
        public static double[] Interval(double from, double to, int steps)
        {
            double range = to - from;
            double stepSize = range / steps;

            if (steps == Int32.MaxValue)
                throw new ArgumentOutOfRangeException("steps",
                    "input must be lesser than Int32.MaxValue");


            double[] r = new double[steps + 1];
            for (int i = 0; i < r.Length; i++)
                r[i] = i * stepSize;

            return r;
        }

        /// <summary>
        ///   Creates a bidimensional mesh matrix.
        /// </summary>
        /// 
        public static double[][] Mesh(DoubleRange rowRange, DoubleRange colRange,
            double rowSteps, double colSteps)
        {
            double[][] mesh = Matrix.CartesianProduct(
                Matrix.Interval(rowRange, rowSteps),
                Matrix.Interval(colRange, colSteps));

            return mesh;
        }
        #endregion


    }
}
