﻿// Accord Math Library
// The Accord.NET Framework
// http://accord-net.origo.ethz.ch
//
// Copyright © César Souza, 2009-2012
// cesarsouza at gmail.com
//
//    This library is free software; you can redistribute it and/or
//    modify it under the terms of the GNU Lesser General Public
//    License as published by the Free Software Foundation; either
//    version 2.1 of the License, or (at your option) any later version.
//
//    This library is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
//    Lesser General Public License for more details.
//
//    You should have received a copy of the GNU Lesser General Public
//    License along with this library; if not, write to the Free Software
//    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
//

namespace Accord.Math
{
    using System;

    public static partial class Matrix
    {



        #region Product
        /// <summary>
        ///   Gets the product of all elements in a vector.
        /// </summary>
        public static double Product(this double[] vector)
        {
            if (vector == null) throw new ArgumentNullException("vector");

            double product = 1.0;
            for (int i = 0; i < vector.Length; i++)
                product *= vector[i];
            return product;
        }

        /// <summary>
        ///   Gets the product of all elements in a vector.
        /// </summary>
        public static int Product(this int[] vector)
        {
            if (vector == null) throw new ArgumentNullException("vector");

            int product = 1;
            for (int i = 0; i < vector.Length; i++)
                product *= vector[i];
            return product;
        }
        #endregion


        #region Operation Mapping (Apply)

        /// <summary>
        ///   Applies a function to every element of the array.
        /// </summary>
        public static void ApplyInPlace<T>(this T[] vector, Func<T, T> func)
        {
            if (vector == null) throw new ArgumentNullException("vector");

            for (int i = 0; i < vector.Length; i++)
                vector[i] = func(vector[i]);
        }

        /// <summary>
        ///   Applies a function to every element of the array.
        /// </summary>
        public static void ApplyInPlace<T>(this T[] vector, Func<T, int, T> func)
        {
            if (vector == null) throw new ArgumentNullException("vector");

            for (int i = 0; i < vector.Length; i++)
                vector[i] = func(vector[i], i);
        }

        /// <summary>
        ///   Applies a function to every element of a matrix.
        /// </summary>
        public static void ApplyInPlace<T>(this T[,] matrix, Func<T, T> func)
        {
            if (matrix == null) throw new ArgumentNullException("matrix");

            int rows = matrix.GetLength(0);
            int cols = matrix.GetLength(1);

            for (int i = 0; i < rows; i++)
                for (int j = 0; j < cols; j++)
                    matrix[i, j] = func(matrix[i, j]);
        }

        /// <summary>
        ///   Applies a function to every element of a matrix.
        /// </summary>
        public static void ApplyInPlace<T>(this T[,] matrix, Func<T, int, int, T> func)
        {
            if (matrix == null) throw new ArgumentNullException("matrix");

            int rows = matrix.GetLength(0);
            int cols = matrix.GetLength(1);

            for (int i = 0; i < rows; i++)
                for (int j = 0; j < cols; j++)
                    matrix[i, j] = func(matrix[i, j], i, j);
        }

        /// <summary>
        ///   Applies a function to every element of the array.
        /// </summary>
        public static TResult[] Apply<TData, TResult>(this TData[] vector, Func<TData, TResult> func)
        {
            if (vector == null) throw new ArgumentNullException("vector");

            TResult[] result = new TResult[vector.Length];

            for (int i = 0; i < vector.Length; i++)
                result[i] = func(vector[i]);

            return result;
        }

        /// <summary>
        ///   Applies a function to every element of the array.
        /// </summary>
        public static TResult[] ApplyWithIndex<TData, TResult>(this TData[] vector, Func<TData, int, TResult> func)
        {
            if (vector == null) throw new ArgumentNullException("vector");

            TResult[] result = new TResult[vector.Length];

            for (int i = 0; i < vector.Length; i++)
                result[i] = func(vector[i], i);

            return result;
        }

        /// <summary>
        ///   Applies a function to every element of a matrix.
        /// </summary>
        public static TResult[,] Apply<TData, TResult>(this TData[,] matrix, Func<TData, TResult> func)
        {
            if (matrix == null) throw new ArgumentNullException("matrix");

            int rows = matrix.GetLength(0);
            int cols = matrix.GetLength(1);

            TResult[,] r = new TResult[rows, cols];

            for (int i = 0; i < rows; i++)
                for (int j = 0; j < cols; j++)
                    r[i, j] = func(matrix[i, j]);

            return r;
        }

        /// <summary>
        ///   Applies a function to every element of a matrix.
        /// </summary>
        public static TResult[,] ApplyWithIndex<TData, TResult>(this TData[,] matrix, Func<TData, int, int, TResult> func)
        {
            if (matrix == null) throw new ArgumentNullException("matrix");

            int rows = matrix.GetLength(0);
            int cols = matrix.GetLength(1);

            TResult[,] result = new TResult[rows, cols];

            for (int i = 0; i < rows; i++)
                for (int j = 0; j < cols; j++)
                    result[i, j] = func(matrix[i, j], i, j);

            return result;
        }
        #endregion


        #region Rounding and discretization
        /// <summary>
        ///   Rounds a double-precision floating-point matrix to a specified number of fractional digits.
        /// </summary>
        public static double[,] Round(this double[,] matrix, int decimals)
        {
            if (matrix == null) throw new ArgumentNullException("matrix");

            int rows = matrix.GetLength(0);
            int cols = matrix.GetLength(1);

            double[,] result = new double[rows, cols];

            for (int i = 0; i < rows; i++)
                for (int j = 0; j < cols; j++)
                    result[i, j] = System.Math.Round(matrix[i, j], decimals);

            return result;
        }

        /// <summary>
        ///   Returns the largest integer less than or equal than to the specified 
        ///   double-precision floating-point number for each element of the matrix.
        /// </summary>
        public static double[,] Floor(this double[,] matrix)
        {
            if (matrix == null) throw new ArgumentNullException("matrix");

            int rows = matrix.GetLength(0);
            int cols = matrix.GetLength(1);

            double[,] result = new double[rows, cols];

            for (int i = 0; i < rows; i++)
                for (int j = 0; j < cols; j++)
                    result[i, j] = System.Math.Floor(matrix[i, j]);

            return result;
        }

        /// <summary>
        ///   Returns the largest integer greater than or equal than to the specified 
        ///   double-precision floating-point number for each element of the matrix.
        /// </summary>
        public static double[,] Ceiling(this double[,] matrix)
        {
            if (matrix == null) throw new ArgumentNullException("matrix");

            int rows = matrix.GetLength(0);
            int cols = matrix.GetLength(1);

            double[,] result = new double[rows, cols];

            for (int i = 0; i < rows; i++)
                for (int j = 0; j < cols; j++)
                    result[i, j] = System.Math.Ceiling(matrix[i, j]);

            return result;
        }

        /// <summary>
        ///   Rounds a double-precision floating-point number array to a specified number of fractional digits.
        /// </summary>
        public static double[] Round(double[] vector, int decimals)
        {
            if (vector == null) throw new ArgumentNullException("vector");

            double[] result = new double[vector.Length];
            for (int i = 0; i < result.Length; i++)
                result[i] = Math.Round(vector[i], decimals);
            return result;
        }

        /// <summary>
        ///   Returns the largest integer less than or equal than to the specified 
        ///   double-precision floating-point number for each element of the array.
        /// </summary>
        public static double[] Floor(double[] vector)
        {
            if (vector == null) throw new ArgumentNullException("vector");

            double[] result = new double[vector.Length];
            for (int i = 0; i < result.Length; i++)
                result[i] = Math.Floor(vector[i]);
            return result;
        }

        /// <summary>
        ///   Returns the largest integer greater than or equal than to the specified 
        ///   double-precision floating-point number for each element of the array.
        /// </summary>
        public static double[] Ceiling(double[] vector)
        {
            if (vector == null) throw new ArgumentNullException("vector");

            double[] result = new double[vector.Length];
            for (int i = 0; i < result.Length; i++)
                result[i] = Math.Ceiling(vector[i]);
            return result;
        }

        #endregion



    }
}

